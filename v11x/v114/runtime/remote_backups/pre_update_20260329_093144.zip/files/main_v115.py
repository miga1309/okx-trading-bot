# === CHANGELOG HEADER ===
# Version: v115
# Date: 2026-03-29
# Changes: implemented UTC minute-based sequential position management cycle, paused market scanner during protected position pass, refreshed popup snapshots on closed-candle/events, and exposed cycle progress/duration in GUI status.
# === END CHANGELOG HEADER ===

import os

os.environ.setdefault("OKX_TURTLE_RUNTIME_VERSION", "v115")

from bootstrap import build_application


def main() -> None:
    app = build_application(app_version='v115', entry_module='main_v115')
    app.run()


if __name__ == '__main__':
    main()
