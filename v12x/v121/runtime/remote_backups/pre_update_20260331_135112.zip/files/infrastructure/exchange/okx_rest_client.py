class OkxRestClientPlaceholder:
    pass
