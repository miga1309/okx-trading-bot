class OkxWsClientPlaceholder:
    pass
